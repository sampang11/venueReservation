import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app.routing';


import { AppComponent } from './app.component';
import { BookingStatusComponent } from './bookingStatus/bookingStatus.component';
import { VenueComponent } from './venue/venue.component';
import { BookingComponent } from './booking/booking.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './nav/nav.component';

import { VenueService } from './venue/venue.service';
import {AlertService} from './service/alert.service';

@NgModule({
  imports: [ BrowserModule,
                   FormsModule,
                   AppRoutingModule,
                   ReactiveFormsModule,
                   ],
  declarations: [ AppComponent,
                          BookingStatusComponent,
                          VenueComponent,
                          BookingComponent,
                          LoginComponent,
                          NavbarComponent
                          ],
  providers: [ VenueService, AlertService ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }