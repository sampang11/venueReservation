"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var app_routing_1 = require("./app.routing");
var app_component_1 = require("./app.component");
var bookingStatus_component_1 = require("./bookingStatus/bookingStatus.component");
var venue_component_1 = require("./venue/venue.component");
var booking_component_1 = require("./booking/booking.component");
var login_component_1 = require("./login/login.component");
var nav_component_1 = require("./nav/nav.component");
var venue_service_1 = require("./venue/venue.service");
var alert_service_1 = require("./service/alert.service");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule,
            forms_1.FormsModule,
            app_routing_1.AppRoutingModule,
            forms_1.ReactiveFormsModule,
        ],
        declarations: [app_component_1.AppComponent,
            bookingStatus_component_1.BookingStatusComponent,
            venue_component_1.VenueComponent,
            booking_component_1.BookingComponent,
            login_component_1.LoginComponent,
            nav_component_1.NavbarComponent
        ],
        providers: [venue_service_1.VenueService, alert_service_1.AlertService],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map