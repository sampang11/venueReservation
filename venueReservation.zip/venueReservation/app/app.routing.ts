import { NgModule } from '@angular/core';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { VenueComponent } from './venue/venue.component';
import { BookingComponent } from './booking/booking.component';
import { LoginComponent } from './login/login.component';
import { BookingStatusComponent } from './bookingStatus/bookingStatus.component';

@NgModule({
    imports: [
        RouterModule.forRoot([
            { path: '', component: VenueComponent },
            { path: 'booking', component: BookingComponent },
            { path: 'login', component: LoginComponent },
            { path: 'bookingStatus', component: BookingStatusComponent },
            { path: '**', redirectTo: '', pathMatch: 'full' }
        ] , { preloadingStrategy: PreloadAllModules })
    ],
    exports: [ RouterModule ]
})
export class AppRoutingModule { }