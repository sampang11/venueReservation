import { Component, OnInit } from '@angular/core';
import { Booking } from '../venue/booking';
import { clone } from 'lodash';
import {findIndex } from 'lodash';

@Component({
    moduleId: module.id,
    templateUrl: 'booking.template.html'
})

export class BookingComponent {
    public loggedIn = false;
    public loggedOut = true;
    bookings: Booking[];
    approveBooking: any = {};
    rejectBooking: any = {};
    accepted = false;
    rejected = false;
    reject = false;
    showBookings = true;
    bookingForm = false;
    editBooking: any = {};
    
    constructor(){
     this.bookings = this.getBookings();
     console.log("Here "+ this.bookings);
    }


 getBookings(): Booking[] {
    
    let localStorageItem = JSON.parse(localStorage.getItem('bookings'));
    console.log(localStorageItem.status);
    return localStorageItem == null ? [] : localStorageItem.bookings;
 }

  saveBooking(booking: Booking):void {
     let booking1 = new Booking(booking.id, booking.location, booking.venueType, booking.name, booking.cid, 
        booking.contactNo, booking.date, booking.time, booking.status, booking.isPending, '');
     this.bookings.push(booking1);
     this.setLocalStorageBookings(this.bookings);
 }

 private setLocalStorageBookings(bookings: Booking[]): void {
     localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
 }

 approveRequest(booking: Booking) {
    console.log(booking);
    booking.status = 'Approved';
    booking.isPending = false;
    this.accepted = true;
    

     setTimeout(function() {
                this.accepted = false;
                console.log(this.accepted);
            }.bind(this), 2000);

    this.approveBooking = clone(booking);
    this.updateBooking(this.approveBooking);
 }

 cancel(){
   this.bookingForm = false;
   this.showBookings = true;
 }

 showRejectForm(booking: Booking){
   this.bookingForm = true;
   this.showBookings = false;
   this.editBooking = booking;
 }

 rejectRequest(booking: Booking) {

   this.bookingForm = false;
   this.showBookings = true;
    
   this.rejected = true;

     setTimeout(function() {
                this.rejected = false;
                console.log(this.rejected);
            }.bind(this), 2000);

    booking.status = 'Rejected';
    booking.isPending = false;
    
    this.approveBooking = clone(booking);
    this.updateBooking(this.approveBooking);
 }

 updateBooking(booking: Booking) {
     let localStorageItem = JSON.parse(localStorage.getItem('bookings'));
     let index = findIndex(localStorageItem.bookings, (b: Booking)=> {
         return b.id === booking.id;
     });
    localStorageItem.bookings[index] = booking;
     this.setLocalStorageBookings(localStorageItem.bookings);
 }

}