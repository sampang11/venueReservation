"use strict";
var Booking = (function () {
    function Booking(id, location, venueType, name, cid, contactNo, date, time) {
        this.id = id;
        this.location = location;
        this.venueType = venueType;
        this.name = name;
        this.cid = cid;
        this.contactNo = contactNo;
        this.date = date;
        this.time = time;
    }
    return Booking;
}());
exports.Booking = Booking;
//# sourceMappingURL=booking.js.map