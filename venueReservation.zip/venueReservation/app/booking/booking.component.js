"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var booking_1 = require("../venue/booking");
var lodash_1 = require("lodash");
var lodash_2 = require("lodash");
var BookingComponent = (function () {
    function BookingComponent() {
        this.loggedIn = false;
        this.loggedOut = true;
        this.approveBooking = {};
        this.rejectBooking = {};
        this.accepted = false;
        this.rejected = false;
        this.reject = false;
        this.showBookings = true;
        this.bookingForm = false;
        this.editBooking = {};
        this.bookings = this.getBookings();
        console.log("Here " + this.bookings);
    }
    BookingComponent.prototype.getBookings = function () {
        var localStorageItem = JSON.parse(localStorage.getItem('bookings'));
        console.log(localStorageItem.status);
        return localStorageItem == null ? [] : localStorageItem.bookings;
    };
    BookingComponent.prototype.saveBooking = function (booking) {
        var booking1 = new booking_1.Booking(booking.id, booking.location, booking.venueType, booking.name, booking.cid, booking.contactNo, booking.date, booking.time, booking.status, booking.isPending, '');
        this.bookings.push(booking1);
        this.setLocalStorageBookings(this.bookings);
    };
    BookingComponent.prototype.setLocalStorageBookings = function (bookings) {
        localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
    };
    BookingComponent.prototype.approveRequest = function (booking) {
        console.log(booking);
        booking.status = 'Approved';
        booking.isPending = false;
        this.accepted = true;
        setTimeout(function () {
            this.accepted = false;
            console.log(this.accepted);
        }.bind(this), 2000);
        this.approveBooking = lodash_1.clone(booking);
        this.updateBooking(this.approveBooking);
    };
    BookingComponent.prototype.cancel = function () {
        this.bookingForm = false;
        this.showBookings = true;
    };
    BookingComponent.prototype.showRejectForm = function (booking) {
        this.bookingForm = true;
        this.showBookings = false;
        this.editBooking = booking;
    };
    BookingComponent.prototype.rejectRequest = function (booking) {
        this.bookingForm = false;
        this.showBookings = true;
        this.rejected = true;
        setTimeout(function () {
            this.rejected = false;
            console.log(this.rejected);
        }.bind(this), 2000);
        booking.status = 'Rejected';
        booking.isPending = false;
        this.approveBooking = lodash_1.clone(booking);
        this.updateBooking(this.approveBooking);
    };
    BookingComponent.prototype.updateBooking = function (booking) {
        var localStorageItem = JSON.parse(localStorage.getItem('bookings'));
        var index = lodash_2.findIndex(localStorageItem.bookings, function (b) {
            return b.id === booking.id;
        });
        localStorageItem.bookings[index] = booking;
        this.setLocalStorageBookings(localStorageItem.bookings);
    };
    return BookingComponent;
}());
BookingComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'booking.template.html'
    }),
    __metadata("design:paramtypes", [])
], BookingComponent);
exports.BookingComponent = BookingComponent;
//# sourceMappingURL=booking.component.js.map