import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    moduleId: module.id,
    templateUrl: 'login.template.html'
})

export class LoginComponent {

    rforms: FormGroup;
    usernameErrorMessage: string;
    passwordErrorMessage: string;
     public failed = false;
     public loggedIn = true;
     public loggedOut = false;

    constructor(private fb: FormBuilder, private router: Router) {

        this.initializedErrorMessage();

        this.rforms = fb.group({
            'username': [null, Validators.required],
            'password': [null, Validators.required]
        });
    }

    initializedErrorMessage() {
        this.usernameErrorMessage = "Username is required";
        this.passwordErrorMessage = "password is required";
    }

    submitDetails(details: any) {

        console.log("Username"+details.username);
        if(details.username == "admin" && details.password == "admin"){
            console.log("navigate");
            this.router.navigate(['/booking']);
        } else{
            this.failed = true;
            setTimeout(function() {
                this.failed = false;
                console.log(this.failed);
            }.bind(this), 2000);
        }
       
    }

}