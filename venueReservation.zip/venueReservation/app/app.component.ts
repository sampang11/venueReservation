import { Component } from '@angular/core';
import {AlertService} from './service/alert.service';
import {Popup} from 'ng2-opd-popup';


@Component({
  moduleId: module.id,
  selector: 'ng-app',
  templateUrl: 'app.template.html'
})

export class AppComponent {
  appName: string = "Venue Reservatation";
  private alertDialog: any;

  constructor(
    private altService: AlertService
  ){
    this.alertDialog = this.altService.alert ;
  }
}
