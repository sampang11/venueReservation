"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BookingStatusComponent = (function () {
    function BookingStatusComponent() {
        this.cancelled = false;
        this.cancelBooking = {};
        this.bookings = this.getBookings();
    }
    BookingStatusComponent.prototype.getBookings = function () {
        var localStorageItem = JSON.parse(localStorage.getItem('bookings'));
        return localStorageItem == null ? [] : localStorageItem.bookings;
    };
    BookingStatusComponent.prototype.cancelRequest = function (booking) {
        this.cancelled = true;
        setTimeout(function () {
            this.cancelled = false;
            console.log(this.cancelled);
        }.bind(this), 2000);
        this.deleteBooking(booking);
    };
    BookingStatusComponent.prototype.deleteBooking = function (booking) {
        var bokkings = this.getBookings();
        bokkings = bokkings.filter(function (bokking) { return bokking.id != booking.id; });
        this.setLocalStorageBookings(bokkings);
    };
    BookingStatusComponent.prototype.findBookings = function (contactNo) {
        var bokkings = this.getBookings();
        bokkings = bokkings.filter(function (bokking) { return bokking.contactNo == contactNo; });
        this.bookings = bokkings;
        console.log("search result: " + this.bookings);
    };
    BookingStatusComponent.prototype.setLocalStorageBookings = function (bookings) {
        localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
    };
    return BookingStatusComponent;
}());
BookingStatusComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'bookingStatus.template.html'
    }),
    __metadata("design:paramtypes", [])
], BookingStatusComponent);
exports.BookingStatusComponent = BookingStatusComponent;
//# sourceMappingURL=bookingStatus.component.js.map