import { Component, OnInit } from '@angular/core';
import { Booking } from '../venue/booking';
import { clone } from 'lodash';
import { findIndex } from 'lodash';

@Component({
    moduleId: module.id,
    templateUrl: 'bookingStatus.template.html'
})

export class BookingStatusComponent {

    bookings: Booking[];
    cancelled = false;
    cancelBooking: any = {};
    newBookings: any;

    constructor(){
     this.bookings = this.getBookings();
    }

   getBookings(): Booking[] {    
    let localStorageItem = JSON.parse(localStorage.getItem('bookings'));
    return localStorageItem == null ? [] : localStorageItem.bookings;
 }

  cancelRequest(booking: Booking) {
   this.cancelled = true;

     setTimeout(function() {
                this.cancelled = false;
                console.log(this.cancelled);
            }.bind(this), 2000);

    this.deleteBooking(booking);
 }

  deleteBooking(booking: Booking) {
    let bokkings = this.getBookings();
    bokkings = bokkings.filter((bokking)=> bokking.id != booking.id);
    this.setLocalStorageBookings(bokkings);
 }

 findBookings(contactNo: number) {
    let bokkings = this.getBookings();
    bokkings = bokkings.filter((bokking)=> bokking.contactNo == contactNo);
    this.bookings = bokkings;
    console.log("search result: "+this.bookings);
 }

  private setLocalStorageBookings(bookings: Booking[]): void {
     localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
 }

}
