import { Component, OnInit } from '@angular/core';
import { Venue } from './venue';
import { VenueService } from './venue.service';
import { Booking } from './booking';

@Component({
    moduleId: module.id,
    templateUrl: 'venue.template.html'
})

export class VenueComponent {
 bookings: Booking[];
 venues: Venue[];
 venueForm: boolean = false;
 showVenues: boolean = true;
 newVenue: any = {};
 nextId: number;
 public success = false;
public loggedIn = true;
public loggedOut = true;
full = false;

 constructor(private _venueService: VenueService){
     this.getBookings();
 }


 ngOnInit(){
     this.getVenues();
    // this.getBookings();
 } 

 getVenues()
 {
   // this.altService.show("Success");
     this.venues = this._venueService.getVenues()
 }

 showVenueForm(venue: Venue){
    // this.altService.show("Success");
    let localStorageItem = JSON.parse(localStorage.getItem('bookings'));
    this.venueForm = true;
    this.showVenues = false;
    this.newVenue = venue;
 }

 cancelBooking() {
    this.venueForm = false;
    this.showVenues = true;
 }

  getBookings(): Booking[] {
   let localStorageItem = JSON.parse(localStorage.getItem('bookings'));
    //console.log("Bookings: "+localStorage.bookings);
    return localStorageItem == null ? [] : localStorageItem.bookings;
 }

saveBooking(booking: Booking): void {

  this.bookings = this.getBookings();

  if(this.bookings.length == 0){
        this.nextId = 1;
  } else {
      let maxId = this.bookings[this.bookings.length - 1].id;
      this.nextId = maxId + 1;
  }

  console.log("length: "+this.bookings.length);

  if(this.bookings.length == 3){
        this.full = true;

         setTimeout(function() {
                this.full = false;
            }.bind(this), 2000);

        this.venueForm = false;
        this.showVenues = true;
  } else {
        let booking1 = new Booking(this.nextId, booking.location, booking.venueType, booking.name, booking.cid, 
        booking.contactNo, booking.date, booking.time, "Pending", true, '');
        console.log(booking1);
        
        this.bookings.push(booking1);
        this.setLocalStorageBookings(this.bookings);

        this.venueForm = false;
        this.showVenues = true;

        this.success = true;
            //wait 2 Seconds and hide
            setTimeout(function() {
                this.success = false;
                console.log(this.success);
            }.bind(this), 2000);
  }
 

}

private setLocalStorageBookings(bookings: Booking[]): void {
     localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
 }

}