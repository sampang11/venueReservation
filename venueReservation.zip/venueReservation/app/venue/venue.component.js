"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var venue_service_1 = require("./venue.service");
var booking_1 = require("./booking");
var VenueComponent = (function () {
    function VenueComponent(_venueService) {
        this._venueService = _venueService;
        this.venueForm = false;
        this.showVenues = true;
        this.newVenue = {};
        this.success = false;
        this.loggedIn = true;
        this.loggedOut = true;
        this.full = false;
        this.getBookings();
    }
    VenueComponent.prototype.ngOnInit = function () {
        this.getVenues();
        // this.getBookings();
    };
    VenueComponent.prototype.getVenues = function () {
        // this.altService.show("Success");
        this.venues = this._venueService.getVenues();
    };
    VenueComponent.prototype.showVenueForm = function (venue) {
        // this.altService.show("Success");
        var localStorageItem = JSON.parse(localStorage.getItem('bookings'));
        this.venueForm = true;
        this.showVenues = false;
        this.newVenue = venue;
    };
    VenueComponent.prototype.cancelBooking = function () {
        this.venueForm = false;
        this.showVenues = true;
    };
    VenueComponent.prototype.getBookings = function () {
        var localStorageItem = JSON.parse(localStorage.getItem('bookings'));
        //console.log("Bookings: "+localStorage.bookings);
        return localStorageItem == null ? [] : localStorageItem.bookings;
    };
    VenueComponent.prototype.saveBooking = function (booking) {
        this.bookings = this.getBookings();
        if (this.bookings.length == 0) {
            this.nextId = 1;
        }
        else {
            var maxId = this.bookings[this.bookings.length - 1].id;
            this.nextId = maxId + 1;
        }
        console.log("length: " + this.bookings.length);
        if (this.bookings.length == 3) {
            this.full = true;
            setTimeout(function () {
                this.full = false;
            }.bind(this), 2000);
            this.venueForm = false;
            this.showVenues = true;
        }
        else {
            var booking1 = new booking_1.Booking(this.nextId, booking.location, booking.venueType, booking.name, booking.cid, booking.contactNo, booking.date, booking.time, "Pending", true, '');
            console.log(booking1);
            this.bookings.push(booking1);
            this.setLocalStorageBookings(this.bookings);
            this.venueForm = false;
            this.showVenues = true;
            this.success = true;
            //wait 2 Seconds and hide
            setTimeout(function () {
                this.success = false;
                console.log(this.success);
            }.bind(this), 2000);
        }
    };
    VenueComponent.prototype.setLocalStorageBookings = function (bookings) {
        localStorage.setItem('bookings', JSON.stringify({ bookings: bookings }));
    };
    return VenueComponent;
}());
VenueComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'venue.template.html'
    }),
    __metadata("design:paramtypes", [venue_service_1.VenueService])
], VenueComponent);
exports.VenueComponent = VenueComponent;
//# sourceMappingURL=venue.component.js.map