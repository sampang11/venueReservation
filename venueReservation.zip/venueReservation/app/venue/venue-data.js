"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VENUE_ITEMS = [{
        id: 1,
        location: 'Thimphu Primary School',
        description: 'Basketball, Football and Vollyball ground',
        openingDays: 'Mon, Tue, Wed, Thus, Sat, Sun',
        openingTime: '6 AM - 11:59 PM',
        imageLink: 'app/shared/images/tps.jpg'
    },
    {
        id: 2,
        location: 'Chanjiji',
        description: 'National football stadium, close on fridays and maintatined by BOC',
        openingDays: 'Mon, Tue, Wed, Thus, Sat, Sun',
        openingTime: '6 AM - 11:59 PM',
        imageLink: 'app/shared/images/chang.jpg'
    },
    {
        id: 3,
        location: 'Chamlingthang',
        description: 'International soccer stadium, close on fridays and maintatined by BOC',
        openingDays: 'Mon, Tue, Wed, Thus, Sat, Sun',
        openingTime: '6 AM - 11:59 PM',
        imageLink: 'app/shared/images/cham.jpg'
    },
    {
        id: 4,
        location: 'Youth Development Fund (YDF)',
        description: 'Multi-sports hall both indoor and outdoor, close on fridays and maintatined by YDF',
        openingDays: 'Mon, Tue, Wed, Thus, Sat, Sun',
        openingTime: '6 AM - 11:59 PM',
        imageLink: 'app/shared/images/ydf.jpg'
    }];
//# sourceMappingURL=venue-data.js.map