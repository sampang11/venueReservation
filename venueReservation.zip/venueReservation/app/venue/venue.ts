export interface Venue {
    id: number;
    location: string;
    description: string;
    openingDays: string;
    openingTime: string;
    imageLink: string;
}