export class Booking {
    id: number;
    location: string;
    venueType: string;
    name: string;
    cid: number;
    contactNo: number;
    date: string;
    time: string;
    status: string;
    isPending: boolean;
    remarks: string;


    constructor(id: number, location: string, venueType: string, name: string, cid: number, 
        contactNo: number, date: string, time: string, status: string, isPending: boolean, remarks: string){
        this.id = id;
        this.location = location;
        this.venueType = venueType;
        this.name = name;
        this.cid = cid;
        this.contactNo = contactNo;
        this.date = date;
        this.time = time;
        this.status = status;
        this.isPending = isPending;
        this.remarks = remarks;
    }
}