import { Injectable } from '@angular/core';
import { Venue } from './venue';
import { VENUE_ITEMS } from './venue-data';

@Injectable()
export class VenueService {

    private vItems = VENUE_ITEMS;
    getVenues(): Venue[] {
        console.log(this.vItems);
        return this.vItems;
    }
}